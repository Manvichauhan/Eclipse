package TestPage;
import org.testng.annotations.Test;
import Files.Customer;

public class CustomerPageTest extends IndexPage {
	@Test
	public void customer() throws InterruptedException {
	Customer customer = new Customer(driver);
	customer.customers();
	}

}
