package TestPage;

import org.testng.annotations.Test;

import Files.Address;


public class AddressPageTest extends IndexPage {
	@Test
	public void Address() throws InterruptedException {
	Address customer = new Address(driver);
	customer.Address();
	
	}


}
