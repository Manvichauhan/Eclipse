package TestPage;

import org.testng.annotations.Test;

import Files.Electronics;

public class ElectronicsPageJava extends IndexPage {
	@Test
	public void Electronics() throws InterruptedException {
		Electronics Electronics = new Electronics(driver);
		Electronics.Electronics();
	}

}
