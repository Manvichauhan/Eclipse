package TestPage;

import org.testng.annotations.Test;

import Files.inner;

public class HeaderTestPage1 extends IndexPage {
	@Test
	public void HeaderTest() throws InterruptedException 
	{
		inner obj1 = new inner(driver);
		obj1.BestSeller();

		
	}


}
