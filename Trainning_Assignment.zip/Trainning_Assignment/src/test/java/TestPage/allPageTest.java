package TestPage;

import org.testng.annotations.Test;

import Files.all;

public class allPageTest extends IndexPage {
	@Test
	public void customer() throws InterruptedException {
	all all = new all(driver);
	all.all();
	}

}
