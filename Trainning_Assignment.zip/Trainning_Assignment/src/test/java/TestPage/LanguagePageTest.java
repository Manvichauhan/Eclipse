package TestPage;

import org.testng.annotations.Test;

import Files.Language;

public class LanguagePageTest extends IndexPage {
	@Test
	public void Language() throws InterruptedException {
		Language login = new Language(driver);
		login.Language();
	}

}
