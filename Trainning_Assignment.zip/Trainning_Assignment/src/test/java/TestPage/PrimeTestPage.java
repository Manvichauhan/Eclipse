package TestPage;


import org.testng.annotations.Test;

import Files.Prime;

public class PrimeTestPage extends IndexPage{
	@Test
	public void Prime() throws InterruptedException {
		Prime login = new Prime(driver);
		login.Prime();
		
	}

}
