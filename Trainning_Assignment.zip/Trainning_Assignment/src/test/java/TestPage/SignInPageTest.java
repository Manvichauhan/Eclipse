package TestPage;
import org.testng.annotations.Test;
import Files.SignIn;

public class SignInPageTest extends IndexPage {
	@Test
	 public void SignInTest() throws InterruptedException {
	 SignIn obj1 = new SignIn(driver);
	 obj1.Sign();
	 }

}
