package TestPage;
import org.testng.annotations.Test;
import Files.Find;

public class FindPageTest extends IndexPage 
{
	@Test
	 public void FindTest() throws InterruptedException 
	{
		 Find obj1 = new Find(driver);
		 obj1.Find();
	 }

}
   