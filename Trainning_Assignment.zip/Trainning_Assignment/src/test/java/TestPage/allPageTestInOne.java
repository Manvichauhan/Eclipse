package TestPage;

import org.testng.annotations.Test;

import Files.Address;
import Files.Customer;
import Files.Electronics;
import Files.Prime;
import Files.all;
import Files.Language;

public class allPageTestInOne extends IndexPage {

	@Test
	public void Address() throws InterruptedException {
	Address customer = new Address(driver);
	customer.Address();
	}
	@Test
	public void customer() throws InterruptedException {
	Customer customer = new Customer(driver);
	customer.customers();
	}
	@Test
	public void Electronics() throws InterruptedException {
	Electronics Electronics = new Electronics(driver);
	Electronics.Electronics();
	}

	@Test
	public void Prime() throws InterruptedException {
		Prime login = new Prime(driver);
		login.Prime();
	}	
	@Test
	public void all() throws InterruptedException {
	all all = new all(driver);
	all.all();
	}
	@Test
	public void Language() throws InterruptedException {
		Language login = new Language(driver);
		login.Language();
	}

}
