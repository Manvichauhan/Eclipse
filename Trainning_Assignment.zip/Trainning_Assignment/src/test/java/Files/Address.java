package Files;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import TestPage.IndexPage;

public class Address extends IndexPage{
	public WebDriver driver;
	public Address(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);
		this.driver=driver;

	}
//	@Test 
//    public void Address() throws InterruptedException {
//    	driver.findElement(By.xpath("//*[@id=\"nav-global-location-popover-link\"]")).click();
//    	test.log(LogStatus.PASS, "Address button clicked successfully");
//    	driver.findElement(By.xpath("//*[@id=\"GLUXZipUpdateInput\"]")).sendKeys("473660");
//    	driver.findElement(By.xpath("//*[@id=\"GLUXZipUpdate\"]/span/input")).click();
//    	
//    }
	@Test 
    public void Address() throws InterruptedException {
    	driver.findElement(By.xpath("//*[@id=\"nav-global-location-popover-link\"]")).click();
    	test.log(LogStatus.PASS, "Address button clicked successfully");
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//*[@id=\"GLUXZipUpdateInput\"]")).sendKeys("473660");
    	driver.findElement(By.xpath("//*[@id=\"GLUXZipUpdate\"]/span/input")).click();
    	driver.findElement(By.xpath("//*[@id=\"nav-global-location-popover-link\"]"));
    	Thread.sleep(1000);
    	
    	
    	
    }
	
}
