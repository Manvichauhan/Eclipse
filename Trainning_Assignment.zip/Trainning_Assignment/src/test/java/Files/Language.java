package Files;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;

import TestPage.IndexPage;

public class Language extends IndexPage{
	WebDriver driver;
	public Language(WebDriver driver) {
	PageFactory.initElements(driver, this);
	this.driver = driver;
	}
	@Test
	  public void Language() throws InterruptedException {
	  	driver.findElement(By.xpath("//*[@id=\"icp-nav-flyout\"]/span/span[2]/span[1]")).click();
	  	driver.findElement(By.xpath("//*[@id=\"icp-language-settings\"]/div[3]/div/label/i")).click();
	  	driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
	  	driver.findElement(By.xpath("//*[@id=\"icp-save-button\"]/span/input")).click();
	  	driver.findElement(By.xpath("//*[@id=\"icp-nav-flyout\"]/span/span[2]/span[1]"));
	  	test.log(LogStatus.PASS, "Language button clicked successfully");
	}	 	


}
