package Files;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import TestPage.IndexPage;

public class SignIn extends IndexPage {
	public WebDriver driver;
	public SignIn(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);
		this.driver=driver;

	}
	public void Sign() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"nav-link-accountList\"]")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.findElement(By.name("email")).sendKeys(prop.getProperty("username"));
		driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"ap_password\"]")).sendKeys(prop.getProperty("password"));
		driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]")).click();
	}

}





