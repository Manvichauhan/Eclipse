package Files;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;
import TestPage.IndexPage;

public class Customer extends IndexPage {
	public WebDriver driver;
	public Customer(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);
		this.driver=driver;

	}
  @Test
  public void customers() throws InterruptedException {
  	driver.findElement(By.xpath("//*[@id=\"nav-xshop\"]/a[4]")).click();
  	driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);        
  	test.log(LogStatus.PASS, "Customer Service button clicked successfully");
  }

}
