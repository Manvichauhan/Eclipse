package Files;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import TestPage.IndexPage;

public class all extends IndexPage {
	public WebDriver driver;
	public all(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);
		this.driver=driver;

	}
  @Test
  public void all() throws InterruptedException {
  	driver.findElement(By.xpath("//*[@id=\"nav-hamburger-menu\"]")).click();
  	driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS); 
  	driver.findElement(By.xpath("//*[@id=\"hmenu-content\"]/ul[1]/li[7]/a")).click();
  	driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS); 
  	driver.findElement(By.xpath("//*[@id=\"hmenu-content\"]/ul[2]/li[5]/a")).click();    
  	test.log(LogStatus.PASS, "All services button clicked successfully");
  }

}
