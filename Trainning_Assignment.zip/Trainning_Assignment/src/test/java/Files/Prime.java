package Files;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;

import TestPage.IndexPage;


public class Prime extends IndexPage {
	public WebDriver driver;
	public Prime(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);
		this.driver=driver;

	}
	 @Test 
	    public void Prime() throws InterruptedException {
	        driver.findElement(By.xpath("//*[@id=\"nav-link-amazonprime\"]/span[1]")).click();
	        driver.findElement(By.xpath("//*[@id=\"a-autoid-0\"]/span")).click();
	        driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS); 
	        driver.findElement(By.name("email")).sendKeys(prop.getProperty("username"));
			driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
			driver.findElement(By.xpath("//*[@id=\"ap_password\"]")).sendKeys(prop.getProperty("password"));
			driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]")).click();
	        test.log(LogStatus.PASS, "Prime Logined successfully");
	    }

}
