Assignment Suite
The following project demonstrate a list of test cases for amazon e commerce web application designed with the help automation tools.
Languages Used - Java
Automation Tools - Selenium, TestNg
Language used- Java Tools- "SELENIUM, TestNg"




Packages Description

Files: Describe a test pages consisting of all elements under test using page object model frameworks.
TestPage: Describe a test cases for the given application under tests.
Trainning.Trainning_Assignment: Describe Utility Class that can be reusable.




BaseClass
•@BeforeClass - driver instances .
•@AfterClass - End browser session and close reports .




configuration.properties file
•Url : URL of Site
•chromedriverProperty : driver used
•chromedriverPath : file system address of driver file




Pages and Test files used
Find and FindPageTest,
inner and HeaderTestPage,
SignIn and SignInPageTest,
IndexPage,
ExtentManager,
ScreenShot