package Testing.API_Testing;
import org.testng.annotations.Test;



import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.Test;
import restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class First_Test {

	@Test
	public  void Create_Token() {
        // TODO Auto-generated method stub
		RestAssured.baseURI = "https://restful-booker.herokuapp.com/apidoc/index.html";
        
        RequestSpecification app1=RestAssured.given();
        
        String data = "{\"username\" : \"admin\",\"password\" : \"password123\"}";
        
        Response res1 = app1.header("Content-Type" , "application/json")
                .body(data)
                .when().post("https://restful-booker.herokuapp.com/auth/");
        res1.prettyPeek();
    
    
		RestAssured.baseURI = "https://restful-booker.herokuapp.com/apidoc/index.html#api-Booking-GetBookings";
		
		RequestSpecification app1=RestAssured.given();
		    
		Response res1 = app1.when().get("https://restful-booker.herokuapp.com/booking");
		res1.prettyPeek();
        
    
        RestAssured.baseURI = "https://restful-booker.herokuapp.com/apidoc/index.html#api-Booking-GetBookings";
        
        RequestSpecification app1=RestAssured.given();
            
        Response res1 = app1.when().get("https://restful-booker.herokuapp.com/booking/67");
        res1.prettyPeek();
        
        
        RestAssured.baseURI = "https://restful-booker.herokuapp.com/apidoc/index.html";
        
        RequestSpecification app1=RestAssured.given();
        
        String data = "{\"firstname\" : \"Jim\",\"lastname\" : \"Brown\",\"totalprice\" : 111, \"depositpaid\" : true,\"bookingdates\" : { \"checkin\":\"2018-01-01\",\"checkout\":\"2019-01-01\"},\"additionalneeds\" : \"Breakfast\"}";
        
        Response res1 = app1.header("Content-Type" , "application/json")
                .body(data)
                .when().post("https://restful-booker.herokuapp.com/booking/");
        res1.prettyPeek();
        
        
    Wrong    RestAssured.baseURI = "https://restful-booker.herokuapp.com/apidoc/index.html";
        
        RequestSpecification app1=RestAssured.given();
        
        String data = "{\"firstname\" : \"James\",\"lastname\" : \"Brown\",\"totalprice\" : 111,\"depositpaid\" : true,\"bookingdates\" : {\"checkin\" : \"2018-01-01\",\"checkout\" : \"2019-01-01\"},\"additionalneeds\" : \"Breakfast\"}";
        
        Response res1 = app1.header("Content-Type" , "application/json")
                .header("Accept" , "application/json")
                .auth().basic("admin", "password123")
                .body(data)
                .when().put("https://restful-booker.herokuapp.com/booking/537/");
        res1.prettyPeek();
        
        
        RestAssured.baseURI = "https://restful-booker.herokuapp.com/apidoc/index.html#api-Booking-GetBookings";
        
        RequestSpecification app1=RestAssured.given();
            
        Response res1 = app1.when().get("https://restful-booker.herokuapp.com/ping");
        res1.prettyPeek();
//        
        
    }

}
}