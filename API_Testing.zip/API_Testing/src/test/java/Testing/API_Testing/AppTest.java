package Testing.API_Testing;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

public class AppTest {
    
  @Test
  public void shouldAnswerWithTrue() {
    assertTrue(true);
  }
}
