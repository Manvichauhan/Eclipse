package stepdef;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import main.BaseClass;
import screens.TOS;

//create class for defining the text stepdefination 
public class TextOption_StepDef extends BaseClass{

	TOS txt = new TOS(driver);					
	@When("^User choose option named as Text$")								
	public void user_choose_option_named_as_Text() {
		txt.text();															
		//text method in screen
	}

	@When("^User click on LogTextBox$")										
	public void user_click_on_LogTextBox() {
		txt.logTextBox();													
	}

	@When("^User click on Add$")											
	public void user_click_on_Add() {
		txt.add();															
	}

	@Then("^User can see line added in box$")								
	public void user_can_see_line_added_in_box() {
		String text = txt.assertCheckUp8();									
		//inserting values in text after returning values from method
		Assert.assertEquals(text, "This is a test\n");
	}

}
