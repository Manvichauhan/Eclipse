//create package for defining the stepdefinations
package stepdef;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import main.BaseClass;
import screens.NFCOS;

public class NFCOption_StepDef extends BaseClass{
	
	NFCOS nfc = new NFCOS(driver);						
	
	@When("^User choose option named as NFC$")								
	public void user_choose_option_named_as_NFC() {
		nfc.nfc();															
	}

	@When("^User click on ForegroundNdefPush$")								
	public void user_click_on_ForegroundNdefPush() {
		nfc.foregroundNdefPush();											
		//foreground ndef push method in screen
	}

	@Then("^User is directed to ForegroundNdefPush$")						
	public void user_is_directed_to_ForegroundNdefPush() {
		String text = nfc.assertCheckUp6();									
		//inserting values in text after returning values from method
		Assert.assertEquals(text, "NFC/ForegroundNdefPush");	
		//Print text
		System.out.println(text);
	}

}
