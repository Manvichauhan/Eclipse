//create package for defining the stepdefinations
package stepdef;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import main.BaseClass;
import screens.GOS;

public class GraphicsOption_StepDef extends BaseClass{
    //object created
	GOS graphic = new GOS(driver);			
	@When("^User choose option named as Graphics$")								
	//when statement
	public void user_choose_option_named_as_Graphics() {
		graphic.graphics();														
		//create graphics method
	}
	@When("^User click on Animate Drawables$")									
	//when statement
	public void user_click_on_Animate_Drawables() {
		graphic.animateDrawables();												
		//animate drawables method in screen
	}

	@Then("^User is directed to Drawables Screen$")								
	//then statement
	public void user_is_directed_to_Drawables_Screen() {
		String text = graphic.assertCheckUp5();									
		//inserting values in text after returning values from method
		Assert.assertEquals(text, "Graphics/AnimateDrawables");				
		System.out.println(text);
	}
}
