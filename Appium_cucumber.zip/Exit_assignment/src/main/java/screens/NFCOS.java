// create a package for (foreground ndef push)
package screens;

import java.time.Duration;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import main.BaseClass;

public class NFCOS extends BaseClass{
	//for logging
	static Logger logger= LogManager.getLogger(NFCOS.class);											
	public String text = "";
	public NFCOS(AppiumDriver<MobileElement> driver) 
	{
		this.driver=driver;
		PageFactory.initElements(new  AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
	}
	@AndroidFindBy(accessibility="NFC")
	//nfc initialized
	public MobileElement NFC;
	
	@AndroidFindBy(accessibility="ForegroundNdefPush")
	//foreground ndef push initialized
	public MobileElement ForegroundNdefPush;																	
	
	@AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[1]/android.view.ViewGroup/android.widget.TextView")
	//checkup6 initialized
	public MobileElement Checkup6;																				
	//nfc method
	public void nfc(){	
		//click function for clicking
		NFC.click();																							
		logger.info("nfc option choosed");
	}
	//foreground ndef push method
	public void foregroundNdefPush() {																			
		ForegroundNdefPush.click();	
		//click function for clicking
		logger.info("ForegroundNdefPush option choosed");
	}
	//assert method
	public String assertCheckUp6() {		
		//getText function for getting text
		text = Checkup6.getText();																				
		System.out.println(text);
		logger.info("checking for assertion");
		//returning text
		return text;																							
	}

}
